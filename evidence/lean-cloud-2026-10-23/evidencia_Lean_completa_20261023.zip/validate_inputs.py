"""Read-only pin/resource preflight. Never treats cached output existence as success."""
from pathlib import Path
import datetime, hashlib, json, shutil, subprocess

ROOT = Path(__file__).resolve().parent
PINS = json.loads((ROOT / 'pins.json').read_text())
def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()
def git(path, *args):
    return subprocess.check_output(['git', '-C', str(path), *args], text=True).strip()
result = {'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'recovered_prior_compiled_outputs': 0, 'checks': []}
repo = ROOT / 'openai'
assert git(repo, 'rev-parse', 'HEAD') == PINS['openai_commit']
assert git(repo, 'rev-parse', 'HEAD^{tree}') == PINS['openai_tree']
assert not git(repo, 'status', '--porcelain', '--untracked-files=no')
assert sha(repo / 'lake-manifest.json') == PINS['manifest_sha256']
for name, expected in PINS['tool_binaries'].items():
    actual = sha(ROOT / 'lean-4.34.0-rc2-linux/bin' / name)
    assert actual == expected, name
    result['checks'].append({'binary': name, 'sha256': actual})
for package in PINS['dependencies']:
    path = repo / '.lake/packages' / package['name']
    assert git(path, 'rev-parse', 'HEAD') == package['commit'], package['name']
    assert not git(path, 'status', '--porcelain', '--untracked-files=no'), package['name']
    result['checks'].append(package)
for source in PINS['study_sources']:
    assert sha(ROOT / source['path']) == source['sha256'], source['path']
    result['checks'].append(source)
result['disk_free_bytes'] = shutil.disk_usage(ROOT).free
assert result['disk_free_bytes'] >= 2 * 1024 ** 3, 'Less than the 2 GiB free-space guard'
result['boot_id'] = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
result['meminfo'] = {line.split(':')[0]: line.split(':')[1].strip()
                     for line in Path('/proc/meminfo').read_text().splitlines()
                     if line.split(':')[0] in {'MemTotal', 'MemAvailable', 'SwapTotal', 'SwapFree'}}
result['all_pins_match'] = True
print(json.dumps(result, indent=2))
