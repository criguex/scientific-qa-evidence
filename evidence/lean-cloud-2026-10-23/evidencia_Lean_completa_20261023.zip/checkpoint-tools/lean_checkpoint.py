#!/usr/bin/env python3
"""Task-scoped, stdlib-only Lean artifact checkpointing. Never executes Lean."""

import argparse
import contextlib
import datetime as dt
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import sys
import tempfile
import zipfile
import zlib

MAX_PART = 40 * 1024 * 1024
CHUNK = 1024 * 1024
SCHEMA = "lean-checkpoint-v1"
MODULE = r"NavierStokes(?:\.[A-Za-z_][A-Za-z0-9_']*)+"
BUILT = re.compile(r"^(?:[✔⚠ℹ]\s+)?(?:\[\d+(?:/\d+)?\]\s+)?Built (" + MODULE + r") \([^\r\n)]*\)\s*$")
ANSI = re.compile(r"\x1b\[[0-9;]*m")
FAMILIES = (".olean", ".ilean", ".trace", ".c", ".setup.json", ".hash")


class CheckpointError(Exception):
    pass


def require(condition, message):
    if not condition:
        raise CheckpointError(message)


def utc_now():
    return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def safe_name(value):
    require(isinstance(value, str) and 0 < len(value) <= 4096, "Invalid member name")
    path = PurePosixPath(value)
    require(path.parts and not path.is_absolute() and str(path) == value, "Non-canonical archive path")
    require(all(p not in (".", "..") and re.fullmatch(r"[A-Za-z0-9_.'-]+", p)
                for p in path.parts), "Unsafe archive path: " + value)
    return path


def checked_directory(path):
    """Reject symlinks in the supplied directory and every parent component."""
    path = Path(os.path.abspath(path))
    require(path.resolve(strict=True) == path, "Directory path contains a symlink")
    require(path.is_dir(), "Not a directory: " + str(path))
    return path


def signature(st):
    return (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns)


def directory_fd(root):
    """Open absolute directory components without following any symlinks."""
    root = Path(root)
    require(root.is_absolute(), "Root must be absolute")
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_DIRECTORY
    fd = os.open("/", flags)
    try:
        for part in root.parts[1:]:
            new_fd = os.open(part, flags, dir_fd=fd)
            os.close(fd)
            fd = new_fd
        return fd
    except BaseException:
        os.close(fd)
        raise


@contextlib.contextmanager
def rooted_open(root, relative, directory=False):
    """Walk only relative components, with O_NOFOLLOW at every opened level."""
    parts = safe_name(relative).parts
    flags = os.O_RDONLY | os.O_NOFOLLOW
    fd = directory_fd(root)
    try:
        for index, part in enumerate(parts):
            is_dir = index < len(parts) - 1 or directory
            new_fd = os.open(part, flags | (os.O_DIRECTORY if is_dir else 0), dir_fd=fd)
            os.close(fd)
            fd = new_fd
        require(stat.S_ISDIR(os.fstat(fd).st_mode) if directory
                else stat.S_ISREG(os.fstat(fd).st_mode), "Non-regular source")
        yield fd
    finally:
        os.close(fd)


def source_ref(path):
    path = Path(os.path.abspath(path))
    return checked_directory(path.parent), path.name


def read_source(root, relative, destination=None):
    """Stream bytes once, checking identity/metadata before and after reading."""
    sha = hashlib.sha256()
    compressor = zlib.compressobj(6, zlib.DEFLATED, -15)
    compressed = size = 0
    with rooted_open(root, relative) as fd:
        before = signature(os.fstat(fd))
        with contextlib.ExitStack() as stack:
            sink = stack.enter_context(open(destination, "xb")) if destination else None
            while True:
                block = os.read(fd, CHUNK)
                if not block:
                    break
                sha.update(block)
                size += len(block)
                compressed += len(compressor.compress(block))
                if sink:
                    sink.write(block)
            compressed += len(compressor.flush())
        require(before == signature(os.fstat(fd)) and size == before[2],
                "File changed while reading: " + relative)
    with rooted_open(root, relative) as fd:
        require(before == signature(os.fstat(fd)), "Source replaced: " + relative)
    return {"size": size, "sha256": sha.hexdigest(), "deflated_size": compressed,
            "signature": before}


def discover(root, module):
    relative = module.replace(".", "/")
    parent, basename = relative.rsplit("/", 1)
    try:
        with rooted_open(root, parent, directory=True) as fd:
            names = os.listdir(fd)
    except FileNotFoundError:
        return []
    # Only each explicitly completed module's parent directory is enumerated.
    return sorted(parent + "/" + name for name in names
                  if name.startswith(basename + ".")
                  and any(name[len(basename):] == family
                          or name[len(basename):].startswith(family + ".") for family in FAMILIES))


def observed_modules(log_sources):
    observations = []
    for item in log_sources:
        with open(item["staged"], encoding="utf-8", errors="strict") as stream:
            for number, line in enumerate(stream, 1):
                original = line.rstrip("\r\n")
                match = BUILT.fullmatch(ANSI.sub("", original))
                if match:
                    observations.append({"module": match.group(1), "log": item["path"],
                                         "line_number": number, "line": original})
    return observations


def sha_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(CHUNK), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False) + "\n",
                    encoding="utf-8")


def partition(groups, maximum):
    # Conservative ZIP/ZIP64 header allowance. Actual final size is also checked.
    def cost(item):
        return item["deflated_size"] + 256 + 2 * len(item["path"].encode("utf-8"))
    result, current, used = [], [], 256
    for group in groups:
        units = [group] if sum(map(cost, group)) + 256 <= maximum else [[x] for x in group]
        for unit in units:
            total = sum(map(cost, unit))
            require(total + 256 <= maximum,
                    "One file cannot fit the part limit; no truncation: " + unit[0]["path"])
            if current and used + total > maximum:
                result.append(current)
                current, used = [], 256
            current.extend(unit)
            used += total
    if current:
        result.append(current)
    return result


def capture(args):
    require(512 <= args.max_part_bytes <= MAX_PART, "Part bound must be 512 bytes to 40 MiB")
    roots = {"lib": checked_directory(args.lib_dir), "ir": checked_directory(args.ir_dir)}
    output = Path(os.path.abspath(args.out))
    checked_directory(output.parent)
    require(not output.exists() and not output.is_symlink(), "Output must not exist")
    excluded = sorted(set(args.exclude_module))
    require(all(re.fullmatch(MODULE, m) for m in excluded), "Invalid excluded module")
    started = utc_now()
    with tempfile.TemporaryDirectory(prefix=".checkpoint-", dir=output.parent) as temp:
        work = Path(temp)
        bundle = work / "bundle"
        bundle.mkdir()
        items, by_path, groups, log_items = [], {}, [], []

        def add(root, relative, archive_path, module=None):
            safe_name(archive_path)
            require(archive_path not in by_path, "Duplicate archive member: " + archive_path)
            staged = work / ("source-%06d" % len(items))
            details = read_source(root, relative, staged)
            item = {**details, "path": archive_path, "module": module,
                    "root": root, "relative": relative, "staged": staged}
            items.append(item)
            by_path[archive_path] = item
            return item

        pins_item = add(*source_ref(args.pins), "evidence/pins.json")
        pins = json.loads(pins_item["staged"].read_text(encoding="utf-8"))
        require(isinstance(pins, dict) and isinstance(pins.get("source"), dict)
                and pins["source"] and isinstance(pins.get("toolchain"), dict)
                and pins["toolchain"], "Pins JSON needs nonempty source and toolchain objects")
        groups.append([pins_item])
        for index, log in enumerate(args.build_log, 1):
            item = add(*source_ref(log), "evidence/build-stdout-%03d.log" % index)
            groups.append([item])
            log_items.append(item)
        for evidence in args.evidence:
            require("=" in evidence, "Evidence must be NAME=PATH")
            name, path = evidence.split("=", 1)
            require(len(safe_name(name).parts) == 1, "Evidence name must be a basename")
            groups.append([add(*source_ref(path), "evidence/" + name)])

        observations = observed_modules(log_items)
        observed = sorted({x["module"] for x in observations})
        selected = sorted(set(observed) - set(excluded))
        inventories = {}
        for module in selected:
            group = []
            for key, root in roots.items():
                relative_names = discover(root, module)
                inventories[(key, module)] = relative_names
                prefix = ".lake/build/lib/lean/" if key == "lib" else ".lake/build/ir/"
                group.extend(add(root, relative, prefix + relative, module) for relative in relative_names)
            primary = ".lake/build/lib/lean/" + module.replace(".", "/") + ".olean"
            require(primary in by_path, "Completed module has no primary .olean: " + module)
            groups.append(group)

        parts = []
        for index, members in enumerate(partition(groups, args.max_part_bytes), 1):
            name = "part-%04d.zip" % index
            path = bundle / name
            with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED,
                                 compresslevel=6, allowZip64=True) as archive:
                for item in members:
                    info = zipfile.ZipInfo(item["path"], date_time=(1980, 1, 1, 0, 0, 0))
                    info.compress_type = zipfile.ZIP_DEFLATED
                    info.external_attr = (stat.S_IFREG | 0o600) << 16
                    with open(item["staged"], "rb") as source, archive.open(info, "w", force_zip64=True) as sink:
                        shutil.copyfileobj(source, sink, CHUNK)
                    item["part"] = name
            require(path.stat().st_size <= args.max_part_bytes, "ZIP exceeds part bound")
            parts.append({"name": name, "size": path.stat().st_size, "sha256": sha_file(path),
                          "members": [item["path"] for item in members]})

        # Re-read every enumerated source; no successful bundle is published on change.
        for item in items:
            fresh = read_source(item["root"], item["relative"])
            require(all(fresh[key] == item[key] for key in ("sha256", "size", "signature")),
                    "Source changed during capture: " + item["relative"])
        for (key, module), before in inventories.items():
            require(discover(roots[key], module) == before,
                    "Module artifact inventory changed: " + module)
        finished = utc_now()
        manifest = {
            "schema": SCHEMA, "snapshot_timestamp": finished,
            "capture_started_at": started, "capture_finished_at": finished,
            "bundle_manifest_complete": True,
            "completeness_meaning": "All explicitly selected stable files are present; not an entire build or proof result.",
            "proof_status": "not_assessed", "source_equivalence": "not_assessed",
            "kernel_audit": "not_performed", "pins": pins,
            "pins_verification": "Caller supplied; no compiler or source-equivalence validation performed.",
            "max_part_bytes": args.max_part_bytes,
            "completed_modules_observed": observed, "successful_build_observations": observations,
            "excluded_modules": excluded, "modules_captured": selected,
            "scope": "Matching artifact families for explicitly successful NavierStokes modules and enumerated evidence only.",
            "files": [{key: item[key] for key in ("path", "module", "size", "sha256", "part")}
                      for item in items], "parts": parts,
        }
        write_json(bundle / "manifest.json", manifest)
        digest = sha_file(bundle / "manifest.json")
        (bundle / "manifest.sha256").write_text(digest + "  manifest.json\n", encoding="ascii")
        verify_bundle(bundle, expected_digest=digest)
        require(not output.exists(), "Output appeared during capture")
        os.rename(bundle, output)
    return {"status": "captured", "output": str(output), "manifest_sha256": digest,
            "modules_captured": selected, "parts": len(parts), "files": len(items),
            "proof_status": "not_assessed"}


def validate_manifest(manifest):
    require(isinstance(manifest, dict), "Manifest must be a JSON object")
    require(manifest.get("schema") == SCHEMA, "Unsupported manifest schema")
    require(manifest.get("bundle_manifest_complete") is True, "Manifest not marked complete")
    require(manifest.get("proof_status") == "not_assessed"
            and manifest.get("source_equivalence") == "not_assessed"
            and manifest.get("kernel_audit") == "not_performed", "Unsupported assurance claims")
    maximum = manifest.get("max_part_bytes")
    require(type(maximum) is int and 512 <= maximum <= MAX_PART, "Invalid ZIP part limit")
    files, parts = manifest.get("files"), manifest.get("parts")
    require(isinstance(files, list) and files and isinstance(parts, list) and parts,
            "Empty or invalid inventory")
    require(all(isinstance(item, dict) for item in files + parts), "Inventory entries must be objects")
    by_path, by_part = {}, {}
    for part in parts:
        name = part.get("name")
        require(isinstance(name, str) and re.fullmatch(r"part-\d{4,}\.zip", name)
                and name not in by_part, "Invalid or duplicate part name")
        require(type(part.get("size")) is int and 0 < part["size"] <= maximum,
                "Invalid part size")
        require(re.fullmatch(r"[0-9a-f]{64}", str(part.get("sha256"))), "Invalid part SHA256")
        require(isinstance(part.get("members"), list), "Invalid part inventory")
        by_part[name] = part
    for item in files:
        path = item.get("path")
        safe_name(path)
        require(path.startswith((".lake/build/lib/lean/NavierStokes/", ".lake/build/ir/NavierStokes/"))
                or (path.startswith("evidence/") and len(PurePosixPath(path).parts) == 2),
                "Member outside checkpoint scope")
        require(path not in by_path, "Duplicate manifest member")
        require(type(item.get("size")) is int and item["size"] >= 0, "Invalid file size")
        require(re.fullmatch(r"[0-9a-f]{64}", str(item.get("sha256"))), "Invalid file SHA256")
        require(item.get("part") in by_part, "Unlisted part")
        by_path[path] = item
    for path in by_path:
        require(not any(str(p) in by_path for p in PurePosixPath(path).parents if str(p) != "."),
                "File/directory path conflict")
    for name, part in by_part.items():
        actual = {path for path, item in by_path.items() if item["part"] == name}
        require(len(part["members"]) == len(actual) and set(part["members"]) == actual,
                "Part/file inventory mismatch")
    return by_path, by_part


def verify_bundle(bundle, expected_digest=None, destination=None, max_restore_bytes=16 * 1024**3):
    bundle = checked_directory(bundle)
    with rooted_open(bundle, "manifest.json") as fd:
        require(os.fstat(fd).st_size <= 64 * 1024**2, "Manifest exceeds 64 MiB")
        raw = b""
        while block := os.read(fd, CHUNK):
            raw += block
    digest = hashlib.sha256(raw).hexdigest()
    with rooted_open(bundle, "manifest.sha256") as fd:
        checksum = os.read(fd, 1024).decode("ascii")
    require(checksum == digest + "  manifest.json\n", "Manifest checksum mismatch")
    if expected_digest is not None:
        require(digest == expected_digest, "Manifest differs from trusted expected SHA256")
    manifest = json.loads(raw)
    by_path, by_part = validate_manifest(manifest)
    total = sum(item["size"] for item in by_path.values())
    require(0 <= total <= max_restore_bytes, "Declared restore size exceeds bound")
    output = None
    if destination is not None:
        output = Path(os.path.abspath(destination))
        checked_directory(output.parent)
        require(not output.exists() and not output.is_symlink(), "Restore destination must not exist")
    with contextlib.ExitStack() as stack:
        opened = []
        for name, part in by_part.items():
            fd = stack.enter_context(rooted_open(bundle, name))
            before = signature(os.fstat(fd))
            require(before[2] == part["size"], "Part size mismatch: " + name)
            stream = stack.enter_context(os.fdopen(os.dup(fd), "rb"))
            h = hashlib.sha256()
            for block in iter(lambda: stream.read(CHUNK), b""):
                h.update(block)
            require(h.hexdigest() == part["sha256"], "Part SHA256 mismatch: " + name)
            stream.seek(0)
            archive = stack.enter_context(zipfile.ZipFile(stream))
            infos = archive.infolist()
            require(len(infos) == len(part["members"])
                    and {i.filename for i in infos} == set(part["members"]), "ZIP member mismatch")
            for info in infos:
                safe_name(info.filename)
                require(not info.flag_bits & 1 and not info.is_dir()
                        and stat.S_ISREG(info.external_attr >> 16), "Unsafe ZIP member type")
                require(info.compress_type in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED),
                        "Unsupported ZIP compression")
                require(info.file_size == by_path[info.filename]["size"], "ZIP file size mismatch")
                verify_member(archive, info, by_path[info.filename])
            require(before == signature(os.fstat(fd)), "Part changed during verification")
            opened.append((fd, before, archive, infos))
        if output is not None:
            temporary = Path(stack.enter_context(tempfile.TemporaryDirectory(
                prefix=".restore-", dir=output.parent)))
            for fd, before, archive, infos in opened:
                for info in infos:
                    path = temporary.joinpath(*safe_name(info.filename).parts)
                    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                    require(path.resolve().is_relative_to(temporary.resolve()), "Restore path escapes destination")
                    with open(path, "xb") as sink:
                        os.chmod(path, 0o600)
                        verify_member(archive, info, by_path[info.filename], sink)
                require(before == signature(os.fstat(fd)), "Part changed during restore")
            # Preserve the checked manifest alongside extracted files for later comparison.
            (temporary / "checkpoint-manifest.json").write_bytes(raw)
            (temporary / "checkpoint-manifest.sha256").write_text(digest + "  checkpoint-manifest.json\n")
            require(not output.exists(), "Restore destination appeared during verification")
            os.rename(temporary, output)
    return {"status": "restored" if output else "verified", "manifest_sha256": digest,
            "files": len(by_path), "parts": len(by_part), "uncompressed_bytes": total,
            "output": str(output) if output else None, "proof_status": "not_assessed"}


def verify_member(archive, info, expected, sink=None):
    h, size = hashlib.sha256(), 0
    with archive.open(info) as stream:
        for block in iter(lambda: stream.read(CHUNK), b""):
            size += len(block)
            require(size <= expected["size"], "Expanded size exceeds manifest")
            h.update(block)
            if sink:
                sink.write(block)
    require(size == expected["size"] and h.hexdigest() == expected["sha256"],
            "File SHA256/size mismatch: " + info.filename)
    # zipfile validates CRC when the member is completely read.


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    build = commands.add_parser("capture", help="Capture explicitly completed modules and frozen evidence")
    build.add_argument("--lib-dir", required=True)
    build.add_argument("--ir-dir", required=True)
    build.add_argument("--build-log", action="append", required=True, help="Frozen Lake stdout log; repeatable")
    build.add_argument("--pins", required=True, help="JSON containing source and toolchain objects")
    build.add_argument("--evidence", action="append", default=[], metavar="NAME=PATH")
    build.add_argument("--exclude-module", action="append", default=[], help="In-flight or invalidated module")
    build.add_argument("--out", required=True, help="New, nonexistent bundle directory")
    build.add_argument("--max-part-bytes", type=int, default=MAX_PART)
    for command in ("verify", "restore"):
        sub = commands.add_parser(command)
        sub.add_argument("bundle")
        sub.add_argument("--expected-manifest-sha256")
        sub.add_argument("--max-restore-bytes", type=int, default=16 * 1024**3)
        if command == "restore":
            sub.add_argument("--destination", required=True, help="New isolated directory; never executes files")
    args = parser.parse_args(argv)
    try:
        if args.command == "capture":
            result = capture(args)
        else:
            result = verify_bundle(args.bundle, args.expected_manifest_sha256,
                                   getattr(args, "destination", None), args.max_restore_bytes)
        print(json.dumps(result, sort_keys=True))
        return 0
    except (CheckpointError, OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile,
            RuntimeError, UnicodeError) as exc:
        print(json.dumps({"status": "failed", "error": str(exc)}), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
