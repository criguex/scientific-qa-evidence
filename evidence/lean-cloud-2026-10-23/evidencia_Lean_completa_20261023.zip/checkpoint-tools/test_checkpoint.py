#!/usr/bin/env python3
"""Small synthetic tests. No Lean process, network, package installs, or uploads."""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import random
import shutil
import stat
import tempfile
import time
import unittest
from unittest import mock
import zipfile

import lean_checkpoint as cp


class CheckpointTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="checkpoint-test-", dir=Path(__file__).parent)
        self.base = Path(self.temp.name)
        self.lib = self.base / "lib"
        self.ir = self.base / "ir"
        (self.lib / "NavierStokes").mkdir(parents=True)
        (self.ir / "NavierStokes").mkdir(parents=True)
        self.log = self.base / "stdout.log"
        self.log.write_text("✔ [1/4] Built NavierStokes.Done (1s)\n"
                            "⚠ [2/4] Built NavierStokes.Warning (2s)\n"
                            "[3/4] Building NavierStokes.Incomplete\n"
                            "error: Built NavierStokes.Fake (1s)\n"
                            "✔ [4/4] Built NavierStokes.Current (1s)\n")
        self.pins = self.base / "pins.json"
        cp.write_json(self.pins, {"source": {"repository": "synthetic-fixture", "commit": "a" * 40},
                                 "toolchain": {"lean_toolchain": "synthetic-not-executed"}})
        self.extra = self.base / "recovery-log.txt"
        self.extra.write_text("Explicit recovery evidence.\n")
        for module in ("Done", "Warning", "Incomplete", "Current", "Fake", "DoneExtra"):
            for suffix in (".olean", ".olean.server", ".olean.private", ".olean.hash", ".ilean",
                           ".ilean.hash", ".trace", ".trace.hash", ".setup.json", ".setup.json.hash"):
                (self.lib / "NavierStokes" / (module + suffix)).write_bytes((module + suffix).encode() * 7)
            for suffix in (".c", ".c.hash", ".c.o", ".c.o.export.hash"):
                (self.ir / "NavierStokes" / (module + suffix)).write_bytes((module + suffix).encode() * 7)
        (self.lib / "NavierStokes" / "Done.custom-secret").write_text("NOT AN ARTIFACT")
        self.args = argparse.Namespace(lib_dir=str(self.lib), ir_dir=str(self.ir),
                                       build_log=[str(self.log)], pins=str(self.pins),
                                       evidence=["recovery.log=" + str(self.extra)],
                                       exclude_module=["NavierStokes.Current"],
                                       out=str(self.base / "bundle"), max_part_bytes=3000)

    def tearDown(self):
        self.temp.cleanup()

    def capture(self):
        result = cp.capture(self.args)
        bundle = Path(self.args.out)
        manifest = json.loads((bundle / "manifest.json").read_text())
        return result, bundle, manifest

    def rehash_manifest(self, bundle, manifest):
        cp.write_json(bundle / "manifest.json", manifest)
        digest = cp.sha_file(bundle / "manifest.json")
        (bundle / "manifest.sha256").write_text(digest + "  manifest.json\n")

    def test_inventory_and_incomplete_exclusion(self):
        result, bundle, manifest = self.capture()
        self.assertEqual(manifest["completed_modules_observed"],
                         ["NavierStokes.Current", "NavierStokes.Done", "NavierStokes.Warning"])
        self.assertEqual(result["modules_captured"], ["NavierStokes.Done", "NavierStokes.Warning"])
        self.assertEqual(len(manifest["files"]), 31)
        for entry in manifest["files"]:
            self.assertFalse(any(x in entry["path"] for x in ("Incomplete", "Current", "Fake", "DoneExtra", "secret")))
        self.assertEqual(manifest["proof_status"], "not_assessed")
        self.assertEqual(manifest["kernel_audit"], "not_performed")

    def test_manifest_part_hashes_and_bounds(self):
        result, bundle, manifest = self.capture()
        self.assertGreater(len(manifest["parts"]), 1)
        self.assertEqual(result["manifest_sha256"], cp.sha_file(bundle / "manifest.json"))
        for part in manifest["parts"]:
            self.assertLessEqual(part["size"], self.args.max_part_bytes)
            self.assertEqual(part["sha256"], cp.sha_file(bundle / part["name"]))
        self.assertEqual(cp.verify_bundle(bundle, result["manifest_sha256"])["status"], "verified")

    def test_restore_matches_every_source_byte(self):
        result, bundle, manifest = self.capture()
        destination = self.base / "isolated-restore"
        restored = cp.verify_bundle(bundle, result["manifest_sha256"], destination)
        self.assertEqual(restored["status"], "restored")
        for entry in manifest["files"]:
            actual = destination / entry["path"]
            self.assertEqual(actual.stat().st_size, entry["size"])
            self.assertEqual(cp.sha_file(actual), entry["sha256"])
            self.assertEqual(stat.S_IMODE(actual.stat().st_mode), 0o600)
        expected = self.lib / "NavierStokes" / "Done.olean"
        self.assertEqual(expected.read_bytes(), (destination / ".lake/build/lib/lean/NavierStokes/Done.olean").read_bytes())
        self.assertTrue((destination / "checkpoint-manifest.json").is_file())

    def test_traversal_rejected_even_with_rehashed_manifest(self):
        _, bundle, manifest = self.capture()
        member = manifest["files"][0]
        old_path = member["path"]
        member["path"] = "../../escape"
        for part in manifest["parts"]:
            part["members"] = [member["path"] if x == old_path else x for x in part["members"]]
        self.rehash_manifest(bundle, manifest)
        with self.assertRaises(cp.CheckpointError):
            cp.verify_bundle(bundle, destination=self.base / "restore")
        self.assertFalse((self.base / "restore").exists())

    def test_unsafe_paths_rejected(self):
        for path in ("../x", "/x", "x/../y", "x//y", "x\\y", "C:/x", "x/./y", ".", ""):
            with self.subTest(path=path), self.assertRaises(cp.CheckpointError):
                cp.safe_name(path)

    def test_tampered_archive_bytes_rejected_before_restore(self):
        _, bundle, manifest = self.capture()
        archive = bundle / manifest["parts"][0]["name"]
        raw = bytearray(archive.read_bytes())
        raw[len(raw) // 2] ^= 1
        archive.write_bytes(raw)
        with self.assertRaisesRegex(cp.CheckpointError, "SHA256"):
            cp.verify_bundle(bundle, destination=self.base / "restore")
        self.assertFalse((self.base / "restore").exists())

    def test_tampered_manifest_and_wrong_trusted_digest_rejected(self):
        _, bundle, _ = self.capture()
        with self.assertRaisesRegex(cp.CheckpointError, "trusted expected"):
            cp.verify_bundle(bundle, expected_digest="0" * 64)
        with (bundle / "manifest.json").open("ab") as stream:
            stream.write(b" ")
        with self.assertRaisesRegex(cp.CheckpointError, "checksum"):
            cp.verify_bundle(bundle)

    def test_per_file_hash_detects_repacked_changed_bytes(self):
        _, bundle, manifest = self.capture()
        part = manifest["parts"][0]
        path = bundle / part["name"]
        with zipfile.ZipFile(path) as archive:
            members = [(copy.copy(info), archive.read(info)) for info in archive.infolist()]
        with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for index, (info, data) in enumerate(members):
                archive.writestr(info, bytes([data[0] ^ 1]) + data[1:] if index == 0 else data)
        part["size"], part["sha256"] = path.stat().st_size, cp.sha_file(path)
        self.rehash_manifest(bundle, manifest)
        with self.assertRaisesRegex(cp.CheckpointError, "File SHA256"):
            cp.verify_bundle(bundle)

    def test_crc_is_checked_even_after_rehashing_archive(self):
        _, bundle, manifest = self.capture()
        part = manifest["parts"][0]
        path = bundle / part["name"]
        data = bytearray(path.read_bytes())
        central_header = data.index(b"PK\x01\x02")
        data[central_header + 16] ^= 1  # Central-directory CRC32, not the member bytes.
        path.write_bytes(data)
        part["sha256"] = cp.sha_file(path)
        self.rehash_manifest(bundle, manifest)
        with self.assertRaisesRegex(zipfile.BadZipFile, "CRC"):
            cp.verify_bundle(bundle, destination=self.base / "restore")
        self.assertFalse((self.base / "restore").exists())

    def test_zip_symlink_type_rejected(self):
        _, bundle, manifest = self.capture()
        part = manifest["parts"][0]
        path = bundle / part["name"]
        with zipfile.ZipFile(path) as archive:
            members = [(copy.copy(info), archive.read(info)) for info in archive.infolist()]
        with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for index, (info, data) in enumerate(members):
                if index == 0:
                    info.external_attr = (stat.S_IFLNK | 0o777) << 16
                archive.writestr(info, data)
        part["size"], part["sha256"] = path.stat().st_size, cp.sha_file(path)
        self.rehash_manifest(bundle, manifest)
        with self.assertRaisesRegex(cp.CheckpointError, "member type"):
            cp.verify_bundle(bundle)

    def test_ansi_success_and_duplicate_observations(self):
        self.log.write_text("\x1b[32m✔ [1/2] Built NavierStokes.Done (1s)\x1b[0m\n"
                            "Built NavierStokes.Done (2s)\n"
                            "✖ [2/2] Built NavierStokes.Fake (1s)\n")
        _, _, manifest = self.capture()
        self.assertEqual(manifest["completed_modules_observed"], ["NavierStokes.Done"])
        self.assertEqual(len(manifest["successful_build_observations"]), 2)

    def test_info_success_marker_is_complete(self):
        self.log.write_text("ℹ [1/2] Built NavierStokes.Done (45s)\n"
                            "info: Not a completed module\n"
                            "✖ [2/2] Built NavierStokes.Fake (1s)\n")
        result, _, manifest = self.capture()
        self.assertEqual(result["modules_captured"], ["NavierStokes.Done"])
        self.assertEqual(len(manifest["successful_build_observations"]), 1)

    def test_new_artifact_during_capture_fails_closed(self):
        original_read, created = cp.read_source, False

        def adding_artifact(root, relative, destination=None):
            nonlocal created
            if destination is None and not created:
                created = True
                (self.lib / "NavierStokes" / "Done.olean.extra.hash").write_bytes(b"new")
            return original_read(root, relative, destination)

        with mock.patch.object(cp, "read_source", side_effect=adding_artifact):
            with self.assertRaisesRegex(cp.CheckpointError, "inventory changed"):
                cp.capture(self.args)
        self.assertFalse(Path(self.args.out).exists())

    def test_changed_file_during_stream_read_rejected(self):
        source = self.lib / "NavierStokes" / "Done.olean"
        original_read, changed = os.read, False

        def changing_read(fd, length):
            nonlocal changed
            data = original_read(fd, length)
            if not changed:
                changed = True
                source.write_bytes(b"changed while open")
            return data

        with mock.patch.object(cp.os, "read", side_effect=changing_read):
            with self.assertRaisesRegex(cp.CheckpointError, "changed while reading"):
                cp.read_source(self.lib, "NavierStokes/Done.olean")

    def test_changed_source_during_capture_fails_closed(self):
        original_read = cp.read_source
        target = self.lib / "NavierStokes" / "Done.olean"

        def changing_read(root, relative, destination=None):
            if destination is None and relative == "NavierStokes/Done.olean":
                target.write_bytes(b"changed between capture and final check")
            return original_read(root, relative, destination)

        with mock.patch.object(cp, "read_source", side_effect=changing_read):
            with self.assertRaisesRegex(cp.CheckpointError, "changed during capture"):
                cp.capture(self.args)
        self.assertFalse(Path(self.args.out).exists())
        self.assertFalse(list(self.base.glob(".checkpoint-*")))

    def test_missing_primary_olean_fails_closed(self):
        (self.lib / "NavierStokes" / "Done.olean").unlink()
        with self.assertRaisesRegex(cp.CheckpointError, "no primary .olean"):
            cp.capture(self.args)
        self.assertFalse(Path(self.args.out).exists())

    def test_artifact_symlink_and_directory_symlink_rejected(self):
        target = self.lib / "NavierStokes" / "Done.olean"
        target.unlink()
        target.symlink_to(self.extra)
        with self.assertRaises(OSError):
            cp.capture(self.args)
        target.unlink()
        target.write_bytes(b"valid again")
        alias = self.base / "alias"
        alias.symlink_to(self.lib, target_is_directory=True)
        self.args.lib_dir = str(alias)
        with self.assertRaisesRegex(cp.CheckpointError, "symlink"):
            cp.capture(self.args)

    def test_indivisible_oversize_file_rejected_without_truncation(self):
        random_bytes = random.Random(42).randbytes(12000)
        (self.lib / "NavierStokes" / "Done.olean").write_bytes(random_bytes)
        with self.assertRaisesRegex(cp.CheckpointError, "no truncation"):
            cp.capture(self.args)
        self.assertFalse(Path(self.args.out).exists())

    def test_empty_build_captures_evidence_only(self):
        self.log.write_text("Building NavierStokes.Incomplete\n")
        result, _, manifest = self.capture()
        self.assertEqual(result["modules_captured"], [])
        self.assertEqual(len(manifest["files"]), 3)

    def test_restore_existing_target_and_size_limit_rejected(self):
        _, bundle, _ = self.capture()
        existing = self.base / "existing"
        existing.mkdir()
        with self.assertRaisesRegex(cp.CheckpointError, "must not exist"):
            cp.verify_bundle(bundle, destination=existing)
        with self.assertRaisesRegex(cp.CheckpointError, "size exceeds bound"):
            cp.verify_bundle(bundle, max_restore_bytes=1)


class RecordingResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.records = []

    def startTest(self, test):
        self.started = time.monotonic()
        super().startTest(test)

    def record(self, test, status, detail=None):
        self.records.append({"test": test.id(), "status": status,
                             "seconds": round(time.monotonic() - self.started, 6), "detail": detail})

    def addSuccess(self, test):
        self.record(test, "passed")
        super().addSuccess(test)

    def addFailure(self, test, error):
        self.record(test, "failed", self._exc_info_to_string(error, test))
        super().addFailure(test, error)

    def addError(self, test, error):
        self.record(test, "error", self._exc_info_to_string(error, test))
        super().addError(test, error)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", default=str(Path(__file__).with_name("test-report.json")))
    args = parser.parse_args()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(CheckpointTests)
    result = unittest.TextTestRunner(verbosity=2, resultclass=RecordingResult).run(suite)
    report = {"timestamp": cp.utc_now(), "scope": "Synthetic stdlib checkpoint tests only; no Lean/compiler execution",
              "passed": result.wasSuccessful(), "tests_run": result.testsRun, "tests": result.records,
              "implementation_sha256": cp.sha_file(Path(cp.__file__)),
              "test_script_sha256": cp.sha_file(Path(__file__))}
    cp.write_json(Path(args.report), report)
    raise SystemExit(0 if result.wasSuccessful() else 1)
