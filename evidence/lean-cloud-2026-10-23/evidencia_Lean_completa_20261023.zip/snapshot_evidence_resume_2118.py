"""Freeze explicit append-only evidence prefixes, then capture a local checkpoint.

No network, upload, daemon, compiler launch, or process signal. Library retention
and verification are deliberately separate, supported tool-mediated steps.
"""
from pathlib import Path
import argparse, datetime, hashlib, json, os, subprocess, sys, uuid

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--state-dir', required=True)
parser.add_argument('--exclude-module', action='append', default=[])
args = parser.parse_args()
def inside(value):
    p = Path(value).resolve()
    if not p.is_relative_to(ROOT):
        raise ValueError('Outside this task directory')
    return p
state_dir = inside(args.state_dir)
state_bytes = (state_dir / 'current.json').read_bytes()
state = json.loads(state_bytes)
run_dir = state_dir / 'runs' / str(uuid.UUID(state['run_id']))
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
snapshot = ROOT / 'checkpoints' / (stamp + '-' + str(uuid.uuid4())[:8])
evidence = snapshot / 'frozen-evidence'
evidence.mkdir(parents=True)
(evidence / 'current.json').write_bytes(state_bytes)
inventory = []
def prefix(src, dest):
    src = inside(src)
    if src.is_symlink():
        raise ValueError('Symlink evidence is not allowed')
    with src.open('rb') as f:
        before = os.fstat(f.fileno())
        data = f.read(before.st_size)
        after = os.fstat(f.fileno())
    if (before.st_dev, before.st_ino) != (after.st_dev, after.st_ino) or after.st_size < before.st_size:
        raise ValueError('Evidence identity/size changed incompatibly')
    # Avoid treating an unfinished stdout or JSONL line as a complete event.
    if data and not data.endswith(b'\n'):
        data = data[:data.rfind(b'\n') + 1]
    (evidence / dest).write_bytes(data)
    inventory.append({'source': str(src.relative_to(ROOT)), 'snapshot': dest,
                      'observed_source_bytes': before.st_size, 'retained_complete_bytes': len(data),
                      'sha256': hashlib.sha256(data).hexdigest()})
prefix(run_dir / 'events.jsonl', 'events-prefix.jsonl')
target = next(s for s in state['plan']['steps']
              if s['argv'] == ['lake', 'build', '+NavierStokes.ComparatorSolution:olean'])
prefix(target['stdout'], 'target-stdout-prefix.log')
prefix(target['stderr'], 'target-stderr-prefix.log')
prefix(ROOT / 'logs/20g_openai_target_serial.stdout.log', 'prior-target-stdout-prefix.log')
receipt = inside(target['receipt']).read_bytes()
json.loads(receipt)
(evidence / 'target-receipt.json').write_bytes(receipt)
(evidence / 'snapshot.json').write_text(json.dumps({'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'run_id': state['run_id'], 'excluded_modules': args.exclude_module,
    'scope': 'Append-only evidence prefixes; not an atomic machine snapshot', 'files': inventory}, indent=2) + '\n')
pins = json.loads((ROOT / 'pins.json').read_text())
checkpoint_pins = {'source': {'repository': 'https://github.com/openai/NavierStokesAndEuler',
    'commit': pins['openai_commit'], 'tree': pins['openai_tree'], 'dependencies': pins['dependencies'],
    'manifest_sha256': pins['manifest_sha256']}, 'toolchain': {'release': 'v4.34.0-rc2',
    'archive_sha256': pins['lean_release_archive']['lean_archive_sha256'], 'binary_sha256': pins['tool_binaries']}}
(evidence / 'checkpoint-pins.json').write_text(json.dumps(checkpoint_pins, indent=2) + '\n')
command = [sys.executable, str(ROOT / 'checkpoint-tools/lean_checkpoint.py'), 'capture',
    '--lib-dir', str(ROOT / 'openai/.lake/build/lib/lean'), '--ir-dir', str(ROOT / 'openai/.lake/build/ir'),
    '--build-log', str(evidence / 'target-stdout-prefix.log'),
    '--build-log', str(evidence / 'prior-target-stdout-prefix.log'), '--pins', str(evidence / 'checkpoint-pins.json'),
    '--out', str(snapshot / 'bundle')]
for name in ['current.json', 'events-prefix.jsonl', 'target-receipt.json', 'snapshot.json', 'target-stderr-prefix.log']:
    command += ['--evidence', name + '=' + str(evidence / name)]
for module in args.exclude_module:
    command += ['--exclude-module', module]
subprocess.run(command, check=True)
print(json.dumps({'snapshot': str(snapshot), 'bundle': str(snapshot / 'bundle'),
                  'library_upload_completed': False, 'proof_status': 'not_assessed'}))
