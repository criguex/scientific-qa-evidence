"""Prepare only the already-approved manifest-pinned Git dependencies; no build."""
from pathlib import Path
import datetime, hashlib, json, os, subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'openai'
EXPECTED = json.loads((ROOT / 'pins.json').read_text())
MANIFEST = REPO / 'lake-manifest.json'
original = MANIFEST.read_bytes()
packages = json.loads(original)['packages']
pins = {p['name']: p for p in EXPECTED['dependencies']}
assert len(packages) == len(pins) == 11
env = dict(os.environ, GIT_TERMINAL_PROMPT='0')
result = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'manifest_sha256': hashlib.sha256(original).hexdigest(), 'dependencies': []}
for p in packages:
    pin = pins[p['name']]
    assert p['url'] == pin['url'] and p['rev'] == pin['commit']
    destination = REPO / '.lake/packages' / p['name']
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not destination.exists():
        subprocess.run(['git', 'init', str(destination)], check=True, env=env)
        subprocess.run(['git', '-C', str(destination), 'remote', 'add', 'origin', p['url']], check=True, env=env)
        subprocess.run(['git', '-C', str(destination), '-c', 'core.hooksPath=/dev/null', 'fetch', '--depth=1', 'origin', p['rev']], check=True, env=env)
        subprocess.run(['git', '-C', str(destination), '-c', 'core.hooksPath=/dev/null', 'checkout', '--detach', 'FETCH_HEAD'], check=True, env=env)
    actual = subprocess.check_output(['git', '-C', str(destination), 'rev-parse', 'HEAD'], text=True).strip()
    clean = not subprocess.check_output(['git', '-C', str(destination), 'status', '--porcelain', '--untracked-files=no'], text=True)
    assert actual == p['rev'] and clean, p['name']
    result['dependencies'].append({'name': p['name'], 'url': p['url'], 'commit': actual, 'tracked_clean': clean})
    print('PIN VERIFIED', p['name'], actual, flush=True)
assert MANIFEST.read_bytes() == original
result['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(ROOT / 'receipts/dependency-pins.json').write_text(json.dumps(result, indent=2) + '\n')
print('ALL 11 PINNED DEPENDENCIES VERIFIED; NO NAVIERSTOKES BUILD STARTED', flush=True)
