"""Controlled tests on disposable Python children only, never the Lean compiler."""
import datetime as dt
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('runner', ROOT / 'resilient_runner.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
BASE = ROOT / 'traceability' / 'selftests' / str(uuid.uuid4())
BASE.mkdir(parents=True)
results = []


def plan(case, label, code):
    folder = BASE / case
    folder.mkdir(exist_ok=True)
    value = {'steps': [{'label': label, 'cwd': str(ROOT),
                       'argv': [sys.executable, '-c', code],
                       'receipt': str(folder / (label + '.json')),
                       'stdout': str(folder / (label + '.stdout')),
                       'stderr': str(folder / (label + '.stderr'))}]}
    path = folder / (label + '-plan.json')
    path.write_text(json.dumps(value))
    return path, folder / 'state'


def command(path, state, extra=()):
    return [sys.executable, str(ROOT / 'resilient_runner.py'), 'run', '--plan', str(path),
            '--state-dir', str(state), '--interval', '0.1', '--min-free-bytes', '0', *extra]


def await_child(state):
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        try:
            d = json.loads((state / 'current.json').read_text())
            if d.get('child') and d.get('last_heartbeat_utc'):
                return d
        except (FileNotFoundError, json.JSONDecodeError):
            pass
        time.sleep(0.02)
    raise AssertionError('Fixture never started')


def chain(state):
    d = json.loads((state / 'current.json').read_text())
    return runner.verify_log(state / 'runs' / d['run_id'] / 'events.jsonl')


for name, exit_code in [('normal', 0), ('failure', 7)]:
    path, state = plan(name, name, f"print('fixture {name}', flush=True); raise SystemExit({exit_code})")
    p = subprocess.run(command(path, state), capture_output=True, text=True, timeout=15)
    assert p.returncode == exit_code, (name, p.stdout, p.stderr)
    d = json.loads((state / 'current.json').read_text())
    assert d['status'] == ('completed' if exit_code == 0 else 'failed')
    results.append({'test': name, 'expected_exit': exit_code, 'observed_exit': p.returncode,
                    'status': d['status'], 'hash_chain': chain(state), 'passed': True})

path, state = plan('controlled_term', 'term', "import time; print('fixture ready', flush=True); time.sleep(20)")
with (BASE / 'controlled_term' / 'runner.stdout').open('w') as out, (BASE / 'controlled_term' / 'runner.stderr').open('w') as err:
    p = subprocess.Popen(command(path, state), stdout=out, stderr=err)
    initial = await_child(state)
    p.send_signal(signal.SIGTERM)
    code = p.wait(timeout=20)
assert code == 143, code
d = json.loads((state / 'current.json').read_text())
assert d['status'] == 'stopped'
assert runner.identity_state(initial['child']) != 'alive'
results.append({'test': 'controlled_term', 'expected_exit': 143, 'observed_exit': code,
                'child_state': runner.identity_state(initial['child']), 'hash_chain': chain(state), 'passed': True})

path, state = plan('abrupt', 'abrupt', "import time; print('fixture ready', flush=True); time.sleep(2); print('fixture done', flush=True)")
with (BASE / 'abrupt' / 'runner.stdout').open('w') as out, (BASE / 'abrupt' / 'runner.stderr').open('w') as err:
    p = subprocess.Popen(command(path, state), stdout=out, stderr=err)
    initial = await_child(state)
    p.kill()  # Only this disposable test monitor is the fault-injection target.
    code = p.wait(timeout=5)
assert code == -signal.SIGKILL
recovery_plan, _ = plan('abrupt', 'recovery', "print('fixture recovered', flush=True)")
blocked = subprocess.run(command(recovery_plan, state), capture_output=True, text=True, timeout=5)
assert blocked.returncode == 73, (blocked.returncode, blocked.stdout, blocked.stderr)
before = json.loads((state / 'current.json').read_text())
assert before['status'] == 'running' and 'exit_code' not in before
abrupt_chain = chain(state)
time.sleep(2.3)  # Let the tiny inherited child finish naturally; never target Lean.
recovery = subprocess.run(command(recovery_plan, state, ['--ack-interrupted', initial['run_id'],
    '--reconciliation-evidence', 'Controlled fixture monitor SIGKILL; short test child allowed to finish naturally.']),
    capture_output=True, text=True, timeout=10)
assert recovery.returncode == 0, (recovery.stdout, recovery.stderr)
reconciled = json.loads((state / 'runs' / initial['run_id'] / 'reconciled.json').read_text())
assert reconciled['status'] == 'interrupted_unknown' and 'exit_code' not in reconciled
results.append({'test': 'abrupt_monitor_and_recovery', 'expected_fixture_monitor_exit': -9,
                'observed_fixture_monitor_exit': code, 'duplicate_launch_blocked_exit': blocked.returncode,
                'unclosed_log_did_not_invent_exit': True, 'recovery_exit': recovery.returncode,
                'prior_log_chain': abrupt_chain, 'recovery_chain': chain(state), 'passed': True})

source = state / 'runs' / initial['run_id'] / 'events.jsonl'
partial = BASE / 'truncated-copy.jsonl'
partial.write_bytes(source.read_bytes() + b'{"unfinished":')
assert runner.verify_log(partial)['truncated_final_line']
altered = BASE / 'altered-copy.jsonl'
lines = source.read_text().splitlines()
entry = json.loads(lines[0]); entry['payload']['kind'] = 'altered'; lines[0] = json.dumps(entry)
altered.write_text('\n'.join(lines) + '\n')
try:
    runner.verify_log(altered)
    raise AssertionError('Alteration was not detected')
except ValueError:
    pass
results.append({'test': 'truncated_tail_and_hash_mismatch', 'passed': True,
                'note': 'Hash chaining is not authentication or encryption.'})

# A descendant ignoring TERM must not outlive a recorded clean shutdown.
path, state = plan('descendant_term', 'tree',
    "import subprocess,sys,time; subprocess.Popen([sys.executable,'-c',"
    "'import signal,time; signal.signal(signal.SIGTERM, signal.SIG_IGN); time.sleep(30)']); time.sleep(30)")
with (BASE / 'descendant_term' / 'runner.stdout').open('w') as out, (BASE / 'descendant_term' / 'runner.stderr').open('w') as err:
    p = subprocess.Popen(command(path, state), stdout=out, stderr=err)
    initial = await_child(state)
    time.sleep(0.4)
    p.send_signal(signal.SIGTERM)
    code = p.wait(timeout=25)
assert code == 143, code
d = json.loads((state / 'current.json').read_text())
assert d['status'] == 'stopped' and not d['own_processes'], d
results.append({'test': 'term_ignoring_descendant_cleanup', 'observed_exit': code,
                'remaining_recorded_processes': d['own_processes'], 'hash_chain': chain(state), 'passed': True})

# Logging failure must not prevent delivery to another owned disposable process.
class BrokenJournal:
    def append(self, *_args, **_kwargs):
        raise OSError('simulated journal write failure')
p = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(10)'])
saved = runner.identity(p.pid)
runner.signal_owned([saved], signal.SIGTERM, BrokenJournal())
assert p.wait(timeout=5) == -signal.SIGTERM
results.append({'test': 'journal_failure_does_not_block_signal', 'passed': True})

saved = runner.identity(os.getpid())
real_identity = runner.identity
runner.identity = lambda pid: {'pid': pid, 'identity_error': 'simulated unreadable stat'}
assert runner.identity_state(saved) == 'unknown_identity_read'
runner.identity = real_identity
results.append({'test': 'unreadable_identity_fails_closed', 'passed': True})

path, state = plan('duplicate_paths', 'duplicate', "print('must not run')")
bad = json.loads(path.read_text());bad['steps'].append(dict(bad['steps'][0]));path.write_text(json.dumps(bad))
rejected = subprocess.run(command(path, state), capture_output=True, text=True, timeout=5)
assert rejected.returncode != 0 and 'Duplicate receipt or log path' in rejected.stderr
assert not Path(bad['steps'][0]['stdout']).exists()
results.append({'test': 'duplicate_output_paths_rejected_before_execution', 'passed': True})

journal_path = BASE / 'simulated-fsync-failure.jsonl'
journal = runner.Journal(journal_path, 'disposable-fsync-test')
real_fsync = runner.os.fsync
runner.os.fsync = lambda _fd: (_ for _ in ()).throw(OSError('simulated fsync failure'))
try:
    try:
        journal.append('fixture')
        raise AssertionError('Expected simulated fsync failure')
    except OSError:
        pass
finally:
    runner.os.fsync = real_fsync
size_after_failure = journal_path.stat().st_size
try:
    journal.append('must_not_append')
    raise AssertionError('Failed journal accepted another append')
except OSError:
    pass
assert journal.seq == 0 and journal_path.stat().st_size == size_after_failure
results.append({'test': 'journal_disables_after_uncertain_append', 'passed': True})

path, state = plan('terminal_write_failure', 'terminal_fixture', "print('completed fixture')")
fault_code = """import sys
import resilient_runner as r
real = r.durable_json
failed = False
def injected(path, data):
    global failed
    if path.name == 'terminal.json' and not failed:
        failed = True
        raise OSError('simulated terminal receipt failure')
    return real(path, data)
r.durable_json = injected
sys.argv = ARGS
raise SystemExit(r.main())
""".replace('ARGS', repr(command(path, state)[1:]))
failed = subprocess.run([sys.executable, '-c', fault_code], cwd=ROOT, capture_output=True, text=True, timeout=10)
assert failed.returncode != 0
d = json.loads((state / 'current.json').read_text())
assert d['status'] == 'monitor_error' and 'exit_code' not in d and d['intended_exit_before_monitor_error'] == 0
results.append({'test': 'terminal_write_failure_not_misreported_success', 'passed': True})
report = {'utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'all_passed': all(x['passed'] for x in results),
          'fixture_scope': 'Disposable Python children only; no Lean process was running or targeted.',
          'tests': results}
(BASE / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'report': str(BASE / 'results.json'), **report}, indent=2))
