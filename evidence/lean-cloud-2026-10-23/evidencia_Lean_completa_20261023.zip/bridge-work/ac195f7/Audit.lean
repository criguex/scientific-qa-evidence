import Bridges
#print Bridges.k1_C
#print Bridges.k1_D
#print axioms Bridges.k1_C
#print axioms Bridges.k1_D
#print Bridges.k1_C_oneSided
#print Bridges.k1_D_oneSided
#print axioms Bridges.k1_C_oneSided
#print axioms Bridges.k1_D_oneSided
