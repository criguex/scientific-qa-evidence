import Bridges
#print Bridges.k1_C
#print Bridges.k1_D
#print axioms Bridges.k1_C
#print axioms Bridges.k1_D
