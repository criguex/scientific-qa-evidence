"""Run one approved Lean source/axiom audit; never execute study shell scripts."""
from pathlib import Path
import argparse, hashlib, json, os, subprocess

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('variant', choices=['c5f4f55', '059a53c', 'ac195f7'])
parser.add_argument('stage', choices=['ClayLiteral', 'Bridges', 'Audit'])
args = parser.parse_args()
pins = json.loads((ROOT / 'pins.json').read_text())
source = ROOT / 'study-sources' / args.variant
work = ROOT / 'bridge-work' / args.variant
work.mkdir(parents=True, exist_ok=True)
for name in ['ClayLiteral.lean', 'Bridges.lean']:
    data = (source / name).read_bytes()
    expected = next(p['sha256'] for p in pins['study_sources'] if p['path'] == str((source / name).relative_to(ROOT)))
    assert hashlib.sha256(data).hexdigest() == expected
    destination = work / name
    if destination.exists():
        assert destination.read_bytes() == data
    else:
        destination.write_bytes(data)
audit = ['import Bridges', '#print Bridges.k1_C', '#print Bridges.k1_D',
         '#print axioms Bridges.k1_C', '#print axioms Bridges.k1_D']
if args.variant == 'ac195f7':
    audit += ['#print Bridges.k1_C_oneSided', '#print Bridges.k1_D_oneSided',
              '#print axioms Bridges.k1_C_oneSided', '#print axioms Bridges.k1_D_oneSided']
audit_text = '\n'.join(audit) + '\n'
if (work / 'Audit.lean').exists():
    assert (work / 'Audit.lean').read_text() == audit_text
else:
    (work / 'Audit.lean').write_text(audit_text)
repo = ROOT / 'openai'
lake = ROOT / 'lean-4.34.0-rc2-linux/bin/lake'
lean = ROOT / 'lean-4.34.0-rc2-linux/bin/lean'
base = subprocess.check_output([str(lake), 'env', 'printenv', 'LEAN_PATH'], cwd=repo, text=True).strip()
paths = [str((repo / p).resolve()) if not Path(p).is_absolute() else p for p in base.split(os.pathsep) if p]
env = dict(os.environ, LEAN_PATH=os.pathsep.join(paths + [str(work)]), LEAN_NUM_THREADS='1')
command = [str(lean), '--root=.']
if args.stage != 'Audit':
    command += ['-o', args.stage + '.olean']
command += [args.stage + '.lean']
print(json.dumps({'variant': args.variant, 'stage': args.stage, 'cwd': str(work), 'argv': command,
                  'LEAN_PATH': env['LEAN_PATH']}), flush=True)
raise SystemExit(subprocess.run(command, cwd=work, env=env).returncode)
