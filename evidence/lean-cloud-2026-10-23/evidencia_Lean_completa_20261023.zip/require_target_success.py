"""Fail closed unless this replacement target has a genuine successful receipt."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent
path = ROOT / 'receipts/20g_openai_target_serial.json'
if not path.exists():
    raise SystemExit('BLOCKED: no replacement target receipt; no bridge compilation started.')
receipt = json.loads(path.read_text())
if receipt.get('exit_code') != 0 or not receipt.get('finished_utc'):
    raise SystemExit('BLOCKED: replacement target not confirmed successful; no bridge compilation started.')
if receipt.get('command') != ['lake', 'build', '+NavierStokes.ComparatorSolution:olean']:
    raise SystemExit('BLOCKED: target command receipt differs.')
if receipt.get('cwd') != str(ROOT / 'openai'):
    raise SystemExit('BLOCKED: target receipt belongs to another workspace.')
print(json.dumps({'target_receipt': str(path), 'run_id': receipt['run_id'],
                  'finished_utc': receipt['finished_utc'], 'exit_code': 0}))
