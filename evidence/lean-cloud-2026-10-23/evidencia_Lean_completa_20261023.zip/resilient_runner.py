#!/usr/bin/env python3
"""Task-scoped, foreground, resumable execution receipts. No daemon or auto-respawn.

SHA-256 chaining detects accidental alteration relative to retained hashes. It is
not encryption, authentication, or tamper-proof storage. SIGKILL cannot be logged
by its victim; an unclosed run is reconciled later as interrupted/unknown.
"""
import argparse
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parent
STOP = None


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def read_text(path):
    try:
        return Path(path).read_text().strip()
    except (OSError, ValueError):
        return None


def boot():
    return read_text('/proc/sys/kernel/random/boot_id')


def pid_namespace():
    try:
        return os.readlink('/proc/self/ns/pid')
    except OSError:
        return None


def identity(pid):
    try:
        raw = Path(f'/proc/{pid}/stat').read_text()
        fields = raw[raw.rfind(')') + 2:].split()
        return {'pid': pid, 'boot_id': boot(), 'pid_namespace': pid_namespace(),
                'start_ticks': int(fields[19]), 'state': fields[0],
                'ppid': int(fields[1]), 'user_ticks': int(fields[11]),
                'system_ticks': int(fields[12]), 'rss_pages': int(fields[21])}
    except FileNotFoundError:
        return None
    except (OSError, ValueError, IndexError) as exc:
        return {'pid': pid, 'identity_error': str(exc)}


def identity_state(saved):
    if not saved:
        return 'unknown'
    if saved.get('identity_error') or not saved.get('start_ticks'):
        return 'unknown_identity'
    if not saved.get('boot_id') or not boot() or not saved.get('pid_namespace') or not pid_namespace():
        return 'unknown_identity_context'
    if saved.get('boot_id') and boot() and saved['boot_id'] != boot():
        return 'absent_after_boot_change'
    if saved.get('pid_namespace') != pid_namespace():
        return 'unknown_other_pid_namespace'
    actual = identity(saved['pid'])
    if not actual:
        return 'absent'
    if actual.get('identity_error'):
        return 'unknown_identity_read'
    if actual['start_ticks'] != saved['start_ticks']:
        return 'absent'
    return 'terminated_zombie' if actual['state'] == 'Z' else 'alive'


def descendants(parent):
    """Inspect only PID/PPID for discovery, then sample this command's descendants."""
    try:
        rows = subprocess.check_output(['ps', '-eo', 'pid=,ppid='], text=True)
        relations = [tuple(map(int, row.split())) for row in rows.splitlines()]
        selected = {parent}
        while True:
            enlarged = selected | {p for p, pp in relations if pp in selected}
            if enlarged == selected:
                break
            selected = enlarged
        return [x for p in sorted(selected) if (x := identity(p))]
    except (OSError, subprocess.SubprocessError, ValueError):
        return [x] if (x := identity(parent)) else []


def safe_path(value):
    path = Path(value).resolve()
    if not path.is_relative_to(ROOT):
        raise ValueError(f'Path outside this task directory: {path}')
    return path


def durable_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.' + str(uuid.uuid4()) + '.tmp')
    with tmp.open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(tmp, path)
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def verify_log(path):
    previous = '0' * 64
    count = 0
    raw = Path(path).read_bytes()
    lines = raw.splitlines(keepends=True)
    partial = False
    for index, line in enumerate(lines):
        if not line.endswith(b'\n') and index == len(lines) - 1:
            partial = True
            break
        record = json.loads(line)
        payload = record['payload']
        encoded = json.dumps(payload, sort_keys=True, separators=(',', ':')).encode()
        digest = hashlib.sha256(encoded).hexdigest()
        if payload['seq'] != count or payload['previous_sha256'] != previous or record['sha256'] != digest:
            raise ValueError(f'Invalid hash chain at line {index + 1}')
        count += 1
        previous = digest
    return {'valid_complete_prefix': True, 'complete_records': count,
            'truncated_final_line': partial, 'last_sha256': previous,
            'authentication_or_encryption': False}


class Journal:
    def __init__(self, path, run_id):
        self.path, self.run_id = path, run_id
        self.seq, self.previous = 0, '0' * 64
        self.failed = None

    def append(self, kind, **data):
        if self.failed:
            raise OSError('Journal disabled after earlier append failure: ' + self.failed)
        payload = {'seq': self.seq, 'run_id': self.run_id, 'utc': utc(),
                   'monotonic_ns': time.monotonic_ns(), 'kind': kind,
                   'previous_sha256': self.previous, 'data': data}
        encoded = json.dumps(payload, sort_keys=True, separators=(',', ':')).encode()
        digest = hashlib.sha256(encoded).hexdigest()
        try:
            with self.path.open('a') as stream:
                stream.write(json.dumps({'payload': payload, 'sha256': digest}, sort_keys=True) + '\n')
                stream.flush()
                os.fsync(stream.fileno())
        except OSError as exc:
            self.failed = str(exc)
            raise
        self.seq += 1
        self.previous = digest
        return payload['utc']


def sample(child_pid):
    result = {'own_processes': descendants(child_pid),
              'disk_free_bytes': shutil.disk_usage(ROOT).free}
    mem = read_text('/proc/meminfo')
    if mem:
        keys = {'MemTotal', 'MemAvailable', 'MemFree', 'SwapTotal', 'SwapFree', 'AnonPages', 'Shmem'}
        result['host_memory_kib'] = {line.split(':')[0]: int(line.split()[1])
                                     for line in mem.splitlines() if line.split(':')[0] in keys}
    vmstat = read_text('/proc/vmstat')
    if vmstat:
        keys = {'oom_kill', 'pgmajfault', 'pgpgin', 'pgpgout'}
        result['host_counters_not_process_attribution'] = {
            line.split()[0]: int(line.split()[1]) for line in vmstat.splitlines()
            if line.split()[0] in keys}
    for proc in result['own_processes']:
        io = read_text(f"/proc/{proc['pid']}/io")
        if io:
            proc['io'] = {line.split(':')[0]: int(line.split()[1]) for line in io.splitlines()}
    return result


def requested_stop(signum, _frame):
    global STOP
    STOP = signum


def best_effort_event(journal, kind, **data):
    try:
        journal.append(kind, **data)
    except (OSError, ValueError) as exc:
        try:
            print('JOURNAL WRITE FAILED:', str(exc), file=sys.stderr, flush=True)
        except OSError:
            pass


def merge_tracked(previous, fresh):
    retained = [x for x in previous if identity_state(x) not in
                {'absent', 'absent_after_boot_change', 'terminated_zombie'}]
    merged = {}
    for item in retained + fresh:
        key = (item.get('boot_id'), item.get('pid_namespace'), item['pid'], item.get('start_ticks'))
        merged[key] = item
    return list(merged.values())


def signal_owned(saved_processes, signum, journal):
    for saved in reversed(saved_processes):
        if identity_state(saved) != 'alive':
            continue
        fd = None
        try:
            # pidfd targets the opened process, not a subsequently reused PID.
            fd = os.pidfd_open(saved['pid'], 0)
            if identity_state(saved) != 'alive':
                continue
            signal.pidfd_send_signal(fd, signum, None, 0)
            best_effort_event(journal, 'signal_forwarded', pid=saved['pid'],
                              start_ticks=saved['start_ticks'], signal=signum)
        except ProcessLookupError:
            pass
        except (OSError, AttributeError) as exc:
            best_effort_event(journal, 'signal_unresolved', pid=saved['pid'], error=str(exc))
        finally:
            if fd is not None:
                os.close(fd)


def cleanup_owned(child, tracked, journal):
    """Used only for an explicit stop or monitor failure, never as a timeout."""
    if child and child.poll() is None:
        tracked = merge_tracked(tracked, descendants(child.pid))
    signal_owned(tracked, signal.SIGTERM, journal)
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        if child and child.poll() is None:
            tracked = merge_tracked(tracked, descendants(child.pid))
        survivors = [x for x in tracked if identity_state(x) == 'alive']
        if not survivors:
            break
        time.sleep(0.1)
    signal_owned(tracked, signal.SIGKILL, journal)
    if child:
        try:
            child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            pass
    grace = time.monotonic() + 3
    while time.monotonic() < grace:
        if not any(identity_state(x) == 'alive' for x in tracked):
            break
        time.sleep(0.1)
    return [x for x in tracked if identity_state(x) not in
            {'absent', 'absent_after_boot_change', 'terminated_zombie'}]


def run(args):
    global STOP
    state_dir = safe_path(args.state_dir)
    state_dir.mkdir(parents=True, exist_ok=True)
    lock = (state_dir / 'task.lock').open('a+')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        print('REFUSED: this task lock is held by an active monitor or inherited child.', flush=True)
        return 73
    current_path = state_dir / 'current.json'
    old = json.loads(current_path.read_text()) if current_path.exists() else None
    if old and old.get('status') in {'running', 'unresolved_processes', 'monitor_error'}:
        states = [identity_state(x) for x in old.get('own_processes', [])]
        if 'alive' in states:
            print('REFUSED: a recorded command process is still alive.', flush=True)
            return 73
        if args.ack_interrupted != old['run_id']:
            print('REFUSED: unclosed prior run requires explicit reconciliation: ' + old['run_id'], flush=True)
            return 74
        if any(x.startswith('unknown') for x in states) and not args.reconciliation_evidence:
            print('REFUSED: process identity is uncertain; external session/process evidence is required.', flush=True)
            return 74
        old['status'] = 'interrupted_unknown'
        old['reconciled_utc'] = utc()
        old['reconciliation'] = {'process_states': states, 'evidence': args.reconciliation_evidence,
                                 'cause': 'not established; no fabricated terminal exit code'}
        durable_json(state_dir / 'runs' / old['run_id'] / 'reconciled.json', old)
    plan_path = safe_path(args.plan)
    plan_bytes = plan_path.read_bytes()
    plan = json.loads(plan_bytes)
    if not isinstance(plan.get('steps'), list) or not plan['steps']:
        raise ValueError('Plan requires a nonempty steps list')
    destinations = set()
    for step in plan['steps']:
        if not re.fullmatch(r'[A-Za-z0-9_-]+', step['label']):
            raise ValueError('Unsafe step label')
        for key in ['cwd', 'receipt', 'stdout', 'stderr']:
            safe_path(step[key])
        for key in ['receipt', 'stdout', 'stderr']:
            destination = safe_path(step[key])
            if destination in destinations:
                raise ValueError('Duplicate receipt or log path in plan')
            destinations.add(destination)
        if not step['argv'] or not all(isinstance(x, str) for x in step['argv']):
            raise ValueError('argv must be a nonempty string list')
        if any(safe_path(step[key]).exists() for key in ['receipt', 'stdout', 'stderr']):
            raise ValueError('Refusing to overwrite existing step receipts/logs; choose a distinct attempt label')
    run_id = str(uuid.uuid4())
    run_dir = state_dir / 'runs' / run_id
    run_dir.mkdir(parents=True)
    journal = Journal(run_dir / 'events.jsonl', run_id)
    state = {'run_id': run_id, 'status': 'running', 'started_utc': utc(),
             'boot_id': boot(), 'pid_namespace': pid_namespace(), 'monitor': identity(os.getpid()),
             'plan_sha256': hashlib.sha256(plan_bytes).hexdigest(),
             'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             'plan': plan, 'own_processes': []}
    journal.append('run_started', monitor=state['monitor'], plan_sha256=state['plan_sha256'],
                   prior_run=old['run_id'] if old else None)
    durable_json(run_dir / 'manifest.json', state)
    durable_json(current_path, state)
    print('RUN', run_id, 'START', state['started_utc'], flush=True)
    for sig in [signal.SIGTERM, signal.SIGINT, signal.SIGHUP]:
        signal.signal(sig, requested_stop)
    env = os.environ.copy()
    env.update(plan.get('environment', {}))
    child = None
    tracked = []
    result = 0
    try:
        for step in plan['steps']:
            if STOP:
                result = 128 + STOP
                break
            receipt = {'run_id': run_id, 'started_utc': utc(), 'cwd': step['cwd'],
                       'command': step['argv'], 'environment': plan.get('environment', {})}
            receipt_path = safe_path(step['receipt'])
            for key in ['stdout', 'stderr']:
                safe_path(step[key]).parent.mkdir(parents=True, exist_ok=True)
            durable_json(receipt_path, receipt)
            started = time.monotonic()
            with safe_path(step['stdout']).open('x') as out, safe_path(step['stderr']).open('x') as err:
                journal.append('command_launch_requested', label=step['label'], argv=step['argv'], cwd=step['cwd'])
                child = subprocess.Popen(step['argv'], cwd=step['cwd'], env=env, stdout=out,
                                         stderr=err, start_new_session=True, pass_fds=(lock.fileno(),))
                tracked = descendants(child.pid)
                state.update(active_step=step['label'], child=identity(child.pid), own_processes=tracked)
                journal.append('command_started', label=step['label'], child=state['child'])
                durable_json(current_path, state)
                next_sample, cleaned = 0.0, False
                while child.poll() is None:
                    if time.monotonic() >= next_sample:
                        try:
                            observation = sample(child.pid)
                            tracked = merge_tracked(tracked, observation['own_processes'])
                            state['own_processes'] = tracked
                            state['last_heartbeat_utc'] = journal.append('heartbeat', step=step['label'], **observation)
                            state['last_event_sha256'] = journal.previous
                            durable_json(current_path, state)
                            if observation['disk_free_bytes'] < args.min_free_bytes:
                                journal.append('disk_guard_triggered', free=observation['disk_free_bytes'])
                                STOP = signal.SIGTERM
                        except (OSError, ValueError, subprocess.SubprocessError) as exc:
                            journal.append('sampling_error', error=str(exc))
                        next_sample = time.monotonic() + args.interval
                    if STOP:
                        journal.append('stop_requested', signal=STOP)
                        tracked = merge_tracked(tracked, descendants(child.pid))
                        tracked = cleanup_owned(child, tracked, journal)
                        cleaned = True
                        break
                    time.sleep(0.2)
                code = child.poll()
                if STOP and not cleaned:
                    tracked = cleanup_owned(child, tracked, journal)
                    code = child.poll()
                elif not STOP:
                    tracked = [x for x in tracked if identity_state(x) not in
                               {'absent', 'absent_after_boot_change', 'terminated_zombie'}]
                state['own_processes'] = tracked
                for stream in [out, err]:
                    stream.flush()
                    os.fsync(stream.fileno())
            receipt.update(observed_utc=utc(), elapsed_seconds=time.monotonic() - started)
            if code is not None:
                receipt.update(finished_utc=utc(), exit_code=code)
            else:
                receipt['status'] = 'unresolved_process_no_terminal_exit'
            durable_json(receipt_path, receipt)
            journal.append('command_exited' if code is not None else 'command_unresolved', label=step['label'], exit_code=code,
                           elapsed_seconds=receipt['elapsed_seconds'])
            print(step['label'], 'EXIT', code, flush=True)
            child = None
            if tracked or code is None:
                journal.append('unresolved_processes', processes=tracked)
                state['status'] = 'unresolved_processes'
                result = 75
                break
            if code != 0 or STOP:
                result = 128 + STOP if STOP else (code if code >= 0 else 128 - code)
                break
        state.update(status='unresolved_processes' if tracked or result == 75 else
                     'completed' if result == 0 else 'stopped' if STOP else 'failed',
                     finished_utc=utc(), exit_code=result)
        journal.append('run_exited', status=state['status'], exit_code=result)
        state['last_event_sha256'] = journal.previous
        state['complete_event_count'] = journal.seq
        durable_json(run_dir / 'terminal.json', state)
        durable_json(current_path, state)
        print('RUN', run_id, state['status'].upper(), result, flush=True)
        return result
    except BaseException as exc:
        # A controlled wrapper failure must not silently orphan its own command.
        tracked = cleanup_owned(child, tracked, journal)
        best_effort_event(journal, 'monitor_exception', error=repr(exc), unresolved_processes=tracked)
        if 'exit_code' in state:
            state['intended_exit_before_monitor_error'] = state.pop('exit_code')
        state.update(status='monitor_error', finished_utc=utc(), monitor_error=repr(exc), own_processes=tracked,
                     journal_error=journal.failed, last_confirmed_durable_sha256=journal.previous,
                     last_confirmed_durable_event_count=journal.seq)
        try:
            durable_json(run_dir / 'terminal.json', state)
            durable_json(current_path, state)
        except OSError as log_error:
            try:
                print('TERMINAL RECEIPT WRITE FAILED:', str(log_error), file=sys.stderr, flush=True)
            except OSError:
                pass
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='action', required=True)
    run_parser = sub.add_parser('run')
    run_parser.add_argument('--plan', required=True)
    run_parser.add_argument('--state-dir', required=True)
    run_parser.add_argument('--interval', type=float, default=30)
    run_parser.add_argument('--min-free-bytes', type=int, default=2 * 1024**3)
    run_parser.add_argument('--ack-interrupted')
    run_parser.add_argument('--reconciliation-evidence', default='')
    status_parser = sub.add_parser('status')
    status_parser.add_argument('--state-dir', required=True)
    verify_parser = sub.add_parser('verify')
    verify_parser.add_argument('log')
    verify_parser.add_argument('--expected-tail')
    args = parser.parse_args()
    if args.action == 'run':
        if args.interval < 0.1:
            parser.error('interval must be at least 0.1 seconds')
        return run(args)
    if args.action == 'verify':
        checked = verify_log(safe_path(args.log))
        if args.expected_tail:
            checked['expected_tail_matches'] = checked['last_sha256'] == args.expected_tail
        print(json.dumps(checked, indent=2))
        return 1 if args.expected_tail and not checked['expected_tail_matches'] else 0
    state_dir = safe_path(args.state_dir)
    state = json.loads((state_dir / 'current.json').read_text())
    print(json.dumps({'checked_utc': utc(), 'state': state,
                      'recorded_process_states': [identity_state(x) for x in state.get('own_processes', [])]}, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
